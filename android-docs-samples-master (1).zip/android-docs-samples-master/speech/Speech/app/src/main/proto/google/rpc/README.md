# Google RPC

This package contains type definitions for general RPC systems. While
[gRPC](https://github.com/grpc) is using these defintions, but they
are not designed specifically to support gRPC.
